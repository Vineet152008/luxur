import Image from 'next/image'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { Navbar } from '@/components/layout/navbar'
import { Footer } from '@/components/layout/footer'
import { Button } from '@/components/ui/button'
import { FadeIn, ScaleIn } from '@/components/ui/motion'
import { formatCurrency } from '@/lib/utils'
import { cars } from '@/data/cars'
import { FaCar, FaTachometerAlt, FaGasPump, FaCogs, FaHorseHead, FaPhone } from 'react-icons/fa'

export function generateMetadata({ params }: { params: { id: string } }) {
  const car = cars.find(car => car.id === params.id)
  
  if (!car) {
    return {
      title: 'Car Not Found | Luxury Motors',
    }
  }
  
  return {
    title: `${car.brand} ${car.model} | Luxury Motors`,
    description: car.description.substring(0, 160) + '...',
  }
}

export default function CarDetailPage({ params }: { params: { id: string } }) {
  const car = cars.find(car => car.id === params.id)
  
  if (!car) {
    notFound()
  }
  
  return (
    <>
      <Navbar />
      <main className="pt-24">
        {/* Hero Section */}
        <section className="relative h-[50vh] lg:h-[70vh] overflow-hidden">
          <Image 
            src={car.gallery[0]} 
            alt={`${car.brand} ${car.model}`}
            fill
            className="object-cover brightness-[0.7]"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-t from-primary via-transparent to-transparent" />
          <div className="container mx-auto px-4 md:px-6 relative z-10 h-full flex flex-col justify-end pb-12">
            <FadeIn>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-text-primary">
                {car.brand} <span className="text-accent">{car.model}</span>
              </h1>
              <p className="text-xl text-text-secondary mt-4">
                {car.specifications.engine} • {car.specifications.power}
              </p>
            </FadeIn>
          </div>
        </section>
        
        {/* Car Information */}
        <section className="py-16">
          <div className="container mx-auto px-4 md:px-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              {/* Main Content */}
              <div className="md:col-span-2">
                <FadeIn>
                  <h2 className="text-2xl font-bold text-text-primary mb-6">Overview</h2>
                  <p className="text-text-secondary leading-relaxed mb-8">
                    {car.description}
                  </p>
                </FadeIn>
                
                {/* Specifications */}
                <FadeIn delay={0.1}>
                  <h2 className="text-2xl font-bold text-text-primary mb-6">Specifications</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                        <FaHorseHead className="text-accent" />
                      </div>
                      <div>
                        <p className="text-text-secondary text-sm">Engine</p>
                        <p className="text-text-primary font-semibold">{car.specifications.engine}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                        <FaHorseHead className="text-accent" />
                      </div>
                      <div>
                        <p className="text-text-secondary text-sm">Power</p>
                        <p className="text-text-primary font-semibold">{car.specifications.power}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                        <FaTachometerAlt className="text-accent" />
                      </div>
                      <div>
                        <p className="text-text-secondary text-sm">Top Speed</p>
                        <p className="text-text-primary font-semibold">{car.specifications.topSpeed}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                        <FaCar className="text-accent" />
                      </div>
                      <div>
                        <p className="text-text-secondary text-sm">Acceleration</p>
                        <p className="text-text-primary font-semibold">{car.specifications.acceleration}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                        <FaCogs className="text-accent" />
                      </div>
                      <div>
                        <p className="text-text-secondary text-sm">Transmission</p>
                        <p className="text-text-primary font-semibold">{car.specifications.transmission}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                        <FaCar className="text-accent" />
                      </div>
                      <div>
                        <p className="text-text-secondary text-sm">Drivetrain</p>
                        <p className="text-text-primary font-semibold">{car.specifications.drivetrain}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                        <FaGasPump className="text-accent" />
                      </div>
                      <div>
                        <p className="text-text-secondary text-sm">Fuel Type</p>
                        <p className="text-text-primary font-semibold">{car.specifications.fuelType}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                        <FaCar className="text-accent" />
                      </div>
                      <div>
                        <p className="text-text-secondary text-sm">Body Type</p>
                        <p className="text-text-primary font-semibold">{car.specifications.bodyType}</p>
                      </div>
                    </div>
                  </div>
                </FadeIn>
                
                {/* Gallery */}
                <FadeIn delay={0.2} className="mt-12">
                  <h2 className="text-2xl font-bold text-text-primary mb-6">Gallery</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {car.gallery.map((image, index) => (
                      <div key={index} className="rounded-xl overflow-hidden aspect-video relative">
                        <Image 
                          src={image}
                          alt={`${car.brand} ${car.model} - Image ${index + 1}`}
                          fill
                          className="object-cover"
                        />
                      </div>
                    ))}
                  </div>
                </FadeIn>
              </div>
              
              {/* Sidebar */}
              <div>
                <ScaleIn>
                  <div className="curved-card p-6 sticky top-24">
                    <div className="mb-4">
                      <p className="text-sm text-text-secondary">Price</p>
                      <p className="text-3xl font-bold text-accent">{formatCurrency(car.price)}</p>
                    </div>
                    
                    <div className="mb-6">
                      <p className="text-sm text-text-secondary mb-2">Available Colors</p>
                      <div className="flex flex-wrap gap-3">
                        {car.colors.map(color => (
                          <div key={color.name} className="group relative">
                            <div 
                              className="w-8 h-8 rounded-full border-2 border-gray-800 cursor-pointer"
                              style={{ backgroundColor: color.hex }}
                              title={color.name}
                            ></div>
                            <span className="absolute -top-10 left-1/2 -translate-x-1/2 bg-secondary px-3 py-1 rounded text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                              {color.name}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <Button href="/contact" className="w-full">
                        Schedule a Viewing
                      </Button>
                      <Button variant="outline" className="w-full">
                        Request Information
                      </Button>
                    </div>
                    
                    <div className="mt-6 pt-6 border-t border-gray-800">
                      <p className="text-text-secondary text-sm mb-4">
                        Interested in this vehicle? Contact our team for more information or to arrange a private viewing.
                      </p>
                      <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 rounded-full bg-accent/10 flex items-center justify-center">
                          <FaPhone className="text-accent text-xs" />
                        </div>
                        <p className="text-text-primary">+1 (555) 123-4567</p>
                      </div>
                    </div>
                  </div>
                </ScaleIn>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
} 