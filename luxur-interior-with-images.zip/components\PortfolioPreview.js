import Image from 'next/image';
import Link from 'next/link';

export default function PortfolioPreview() {
  const featuredProjects = [
    {
      id: 1,
      title: 'Serene Lakeside Retreat',
      category: 'Residential',
      imageUrl: '/images/portfolio/lakeside-retreat.jpg',
      alt: 'Minimalist lakeside living room with panoramic views'
    },
    {
      id: 2,
      title: 'Urban Loft Transformation',
      category: 'Residential',
      imageUrl: '/images/portfolio/urban-loft.jpg',
      alt: 'Modern open-concept loft space with warm accents'
    },
    {
      id: 3,
      title: 'Boutique Law Office',
      category: 'Commercial',
      imageUrl: '/images/portfolio/law-office.jpg',
      alt: 'Elegant law office reception with minimalist design'
    },
    {
      id: 4,
      title: 'Coastal Family Kitchen',
      category: 'Kitchen Design',
      imageUrl: '/images/portfolio/coastal-kitchen.jpg',
      alt: 'Bright coastal kitchen with natural materials'
    }
  ];

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Featured Projects</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Explore our portfolio of carefully crafted spaces that balance aesthetic beauty with practical functionality.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProjects.map((project) => (
            <div key={project.id} className="group relative overflow-hidden rounded-lg shadow-md hover:shadow-xl transition-all duration-300">
              <div className="relative h-64 w-full">
                <Image 
                  src={project.imageUrl}
                  alt={project.alt}
                  fill
                  style={{objectFit: 'cover'}}
                  className="transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black bg-opacity-20 group-hover:bg-opacity-40 transition-all duration-300"></div>
                
                <div className="absolute inset-0 flex flex-col justify-end p-6 text-white">
                  <span className="text-xs uppercase tracking-wider mb-2 opacity-90">{project.category}</span>
                  <h3 className="text-xl font-bold">{project.title}</h3>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Link 
            href="/portfolio" 
            className="btn-outline inline-block py-3 px-8 border border-accent text-accent hover:bg-accent hover:text-white transition-colors duration-300"
          >
            View All Projects
          </Link>
        </div>
      </div>
    </section>
  );
} 