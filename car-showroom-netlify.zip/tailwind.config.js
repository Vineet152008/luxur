/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        'primary': '#101010', // Dark black
        'secondary': '#1A1A1A', // Slightly lighter black
        'accent': '#D4AF37', // Gold
        'accent-silver': '#C0C0C0', // Silver
        'accent-red': '#8B0000', // Deep red
        'text-primary': '#FFFFFF',
        'text-secondary': '#CCCCCC', 
      },
      borderRadius: {
        'xl': '1rem',
        '2xl': '1.5rem',
        '3xl': '2rem',
        '4xl': '2.5rem',
      },
      fontFamily: {
        'sans': ['Montserrat', 'sans-serif'],
        'display': ['Poppins', 'sans-serif'],
      },
      boxShadow: {
        'card': '0 10px 30px -15px rgba(0, 0, 0, 0.3)',
        'card-hover': '0 20px 40px -15px rgba(0, 0, 0, 0.5)',
      },
    },
  },
  plugins: [],
} 