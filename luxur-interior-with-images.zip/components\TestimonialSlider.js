'use client';

import { useState } from 'react';

export default function TestimonialSlider() {
  const testimonials = [
    {
      id: 1,
      quote: "Luxur Interior transformed our home into a sanctuary that perfectly reflects our personality and lifestyle. Their attention to detail and focus on sustainable materials exceeded our expectations.",
      author: "Emily & David Johnson",
      position: "Residential Client",
      location: "Waterfront Estate"
    },
    {
      id: 2,
      quote: "Working with Luxur on our office redesign was seamless. They created a space that enhances our company culture while maintaining functionality. Our team loves coming to work every day.",
      author: "Michael Roberts",
      position: "CEO",
      location: "Atlas Financial Group"
    },
    {
      id: 3,
      quote: "The kitchen renovation Luxur designed has completely changed how we use our home. They found the perfect balance between aesthetics and practicality, making cooking and entertaining a joy.",
      author: "Sarah Williams",
      position: "Residential Client",
      location: "Modern Farmhouse"
    }
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  const nextTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length);
  };

  const goToTestimonial = (index) => {
    setCurrentIndex(index);
  };

  return (
    <section className="bg-neutral-100 py-20">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-16">What Our Clients Say</h2>

          <div className="relative">
            {testimonials.map((testimonial, index) => (
              <div 
                key={testimonial.id} 
                className={`transition-opacity duration-500 ${
                  index === currentIndex ? 'opacity-100' : 'opacity-0 absolute inset-0'
                }`}
              >
                <blockquote className="text-xl italic mb-8">
                  "{testimonial.quote}"
                </blockquote>
                <div className="mt-6">
                  <p className="font-semibold text-lg">{testimonial.author}</p>
                  <p className="text-sm text-gray-600">{testimonial.position}, {testimonial.location}</p>
                </div>
              </div>
            ))}

            <div className="flex justify-center items-center mt-10 space-x-4">
              <button 
                onClick={prevTestimonial}
                className="w-10 h-10 rounded-full border border-gray-300 flex items-center justify-center text-gray-600 hover:bg-accent hover:text-white hover:border-accent transition-colors"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              
              <div className="flex space-x-2">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => goToTestimonial(index)}
                    className={`w-2 h-2 rounded-full transition-colors ${
                      index === currentIndex ? 'bg-accent' : 'bg-gray-300'
                    }`}
                    aria-label={`Go to testimonial ${index + 1}`}
                  ></button>
                ))}
              </div>
              
              <button 
                onClick={nextTestimonial}
                className="w-10 h-10 rounded-full border border-gray-300 flex items-center justify-center text-gray-600 hover:bg-accent hover:text-white hover:border-accent transition-colors"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
} 