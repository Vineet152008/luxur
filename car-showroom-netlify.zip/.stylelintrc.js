module.exports = {
  extends: ['stylelint-config-standard'],
  rules: {
    'at-rule-no-unknown': null,
    'function-no-unknown': null,
    'selector-class-pattern': null,
    'function-url-quotes': null,
    'declaration-block-trailing-semicolon': null,
    'no-descending-specificity': null,
    'selector-pseudo-class-no-unknown': [
      true,
      {
        ignorePseudoClasses: ['global', 'local']
      }
    ],
    'at-rule-empty-line-before': [
      'always',
      {
        except: ['blockless-after-same-name-blockless', 'first-nested'],
        ignore: ['after-comment'],
        ignoreAtRules: ['tailwind', 'apply', 'layer', 'screen']
      }
    ]
  },
  overrides: [
    {
      files: ['**/*.css'],
      customSyntax: 'postcss-scss'
    }
  ],
  ignoreFiles: ['**/*.js', '**/*.jsx', '**/*.ts', '**/*.tsx']
}; 