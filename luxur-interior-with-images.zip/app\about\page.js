import Image from 'next/image';

export default function About() {
  const teamMembers = [
    {
      id: 1,
      name: 'Jane Doe',
      role: 'Principal Designer',
      image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80',
      bio: 'With over 15 years of experience, Jane brings a wealth of knowledge and innovative thinking to every project.',
    },
    {
      id: 2,
      name: 'John Smith',
      role: 'Interior Architect',
      image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80',
      bio: 'John specializes in creating functional yet beautiful spaces, with a keen eye for structural elements and spatial planning.',
    },
    {
      id: 3,
      name: 'Emily Chen',
      role: 'Color Specialist',
      image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80',
      bio: 'Emily\'s expertise in color theory helps create the perfect palette for each unique space and client personality.',
    },
  ];

  return (
    <div className="min-h-screen py-16">
      <div className="container-custom">
        {/* Hero Section */}
        <div className="relative h-[40vh] mb-16 overflow-hidden rounded-sm">
          <Image
            src="https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80"
            alt="Our Design Studio"
            fill
            style={{ objectFit: 'cover' }}
            priority
            className="brightness-[0.8]"
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <h1 className="text-4xl md:text-5xl text-white font-bold">Our Story</h1>
          </div>
        </div>

        {/* About Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
          <div className="animate-fade-in">
            <h2 className="section-title">Who We Are</h2>
            <p className="mb-4">Founded in 2010, Luxur Interior has established itself as a premier interior design studio specializing in warm minimalism. We believe that spaces should be both beautiful and functional, creating environments that inspire and comfort.</p>
            <p>Our team of passionate designers brings together expertise from various design disciplines to create cohesive, thoughtful interiors that reflect each client's unique personality and lifestyle needs.</p>
          </div>
          <div className="animate-slide-up">
            <h2 className="section-title">Our Mission</h2>
            <p className="mb-4">At Luxur Interior, our mission is to transform ordinary spaces into extraordinary experiences. We strive to create environments that balance aesthetic beauty with practical functionality, using sustainable materials and ethical practices.</p>
            <p>We believe that thoughtful design has the power to enhance daily life, and we're committed to bringing that belief into every project we undertake.</p>
          </div>
        </div>

        {/* Team Section */}
        <div className="mb-16">
          <h2 className="section-title text-center mb-12">Meet Our Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {teamMembers.map((member) => (
              <div key={member.id} className="card hover:-translate-y-1">
                <div className="relative h-80 mb-4 overflow-hidden rounded-sm">
                  <Image
                    src={member.image}
                    alt={member.name}
                    fill
                    style={{ objectFit: 'cover' }}
                    className="transition-transform duration-700 hover:scale-105"
                  />
                </div>
                <h3 className="text-xl font-bold mb-1">{member.name}</h3>
                <p className="text-accent font-medium mb-3">{member.role}</p>
                <p>{member.bio}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Values */}
        <div className="bg-secondary p-12 rounded-sm">
          <h2 className="section-title text-center mb-12">Our Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Innovation</h3>
              <p>We constantly explore new ideas and approaches to create unique design solutions.</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Quality</h3>
              <p>We're committed to excellence in every detail, from concept to execution.</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Sustainability</h3>
              <p>We prioritize eco-friendly materials and practices in all our design work.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
} 