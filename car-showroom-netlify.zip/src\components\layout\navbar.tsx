'use client'

import Link from 'next/link'
import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'

const navLinks = [
  { label: 'Home', href: '/' },
  { label: 'Cars', href: '/cars' },
  { label: 'About', href: '/about' },
  { label: 'Contact', href: '/contact' },
]

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  // Track scroll position for navbar transparency
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true)
      } else {
        setScrolled(false)
      }
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  // Close mobile menu when a link is clicked
  const closeMobileMenu = () => {
    setIsOpen(false)
  }

  return (
    <header 
      className={cn(
        'fixed top-0 left-0 right-0 z-50 w-full transition-all duration-300',
        scrolled 
          ? 'bg-primary/95 backdrop-blur py-3 shadow-lg' 
          : 'bg-transparent py-5'
      )}
    >
      <nav className="container mx-auto px-4 md:px-6 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="z-50">
          <span className="text-2xl font-bold text-accent font-display">
            LUXURY<span className="text-text-primary">MOTORS</span>
          </span>
        </Link>

        {/* Desktop Navigation */}
        <ul className="hidden md:flex items-center space-x-8">
          {navLinks.map((link) => (
            <li key={link.href}>
              <Link 
                href={link.href}
                className="text-text-secondary hover:text-text-primary transition-colors relative group"
              >
                {link.label}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-accent transition-all duration-300 group-hover:w-full" />
              </Link>
            </li>
          ))}
        </ul>

        {/* CTA Button */}
        <div className="hidden md:block">
          <Button href="/contact" size="md">
            Schedule Viewing
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden z-50 w-8 h-8 flex flex-col justify-center items-center"
          onClick={() => setIsOpen(!isOpen)}
          aria-label="Toggle menu"
        >
          <span 
            className={cn(
              'block w-6 h-0.5 bg-white transition-all duration-300 ease-out', 
              isOpen ? 'rotate-45 translate-y-1' : '-translate-y-1'
            )} 
          />
          <span 
            className={cn(
              'block w-6 h-0.5 bg-white transition-all duration-300 ease-out',
              isOpen ? 'opacity-0' : 'opacity-100'
            )} 
          />
          <span 
            className={cn(
              'block w-6 h-0.5 bg-white transition-all duration-300 ease-out', 
              isOpen ? '-rotate-45 -translate-y-1' : 'translate-y-1'
            )} 
          />
        </button>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isOpen && (
            <motion.div 
              className="fixed inset-0 bg-primary/95 flex flex-col items-center justify-center md:hidden"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <ul className="flex flex-col items-center space-y-8 text-lg">
                {navLinks.map((link) => (
                  <motion.li 
                    key={link.href}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 }}
                  >
                    <Link 
                      href={link.href}
                      className="text-text-primary hover:text-accent transition-colors"
                      onClick={closeMobileMenu}
                    >
                      {link.label}
                    </Link>
                  </motion.li>
                ))}
                <motion.li
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <Button 
                    href="/contact" 
                    size="lg"
                    onClick={closeMobileMenu}
                  >
                    Schedule Viewing
                  </Button>
                </motion.li>
              </ul>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>
    </header>
  )
} 