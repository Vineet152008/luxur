'use client'

import Link from 'next/link'
import { FaFacebookF, FaTwitter, FaInstagram, FaYoutube } from 'react-icons/fa'
import { Button } from '@/components/ui/button'
import { FadeIn } from '@/components/ui/motion'

export function Footer() {
  return (
    <footer className="bg-secondary pt-16 pb-8 text-text-secondary">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand column */}
          <FadeIn className="space-y-4" delay={0.1}>
            <div>
              <span className="text-xl font-bold text-accent font-display">
                LUXURY<span className="text-text-primary">MOTORS</span>
              </span>
            </div>
            <p className="max-w-xs">
              Experience automotive excellence with our curated collection of the world's most luxurious vehicles.
            </p>
            <div className="flex space-x-4 pt-2">
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" 
                className="w-10 h-10 rounded-full bg-primary flex items-center justify-center hover:bg-accent hover:text-black transition-colors">
                <FaFacebookF />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" 
                className="w-10 h-10 rounded-full bg-primary flex items-center justify-center hover:bg-accent hover:text-black transition-colors">
                <FaTwitter />
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" 
                className="w-10 h-10 rounded-full bg-primary flex items-center justify-center hover:bg-accent hover:text-black transition-colors">
                <FaInstagram />
              </a>
              <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" 
                className="w-10 h-10 rounded-full bg-primary flex items-center justify-center hover:bg-accent hover:text-black transition-colors">
                <FaYoutube />
              </a>
            </div>
          </FadeIn>

          {/* Quick Links */}
          <FadeIn className="space-y-4" delay={0.2}>
            <h3 className="text-lg font-medium text-text-primary">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="hover:text-accent transition-colors">Home</Link>
              </li>
              <li>
                <Link href="/cars" className="hover:text-accent transition-colors">Cars</Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-accent transition-colors">About Us</Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-accent transition-colors">Contact</Link>
              </li>
            </ul>
          </FadeIn>

          {/* Services */}
          <FadeIn className="space-y-4" delay={0.3}>
            <h3 className="text-lg font-medium text-text-primary">Services</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/services/financing" className="hover:text-accent transition-colors">Financing</Link>
              </li>
              <li>
                <Link href="/services/test-drive" className="hover:text-accent transition-colors">Test Drive</Link>
              </li>
              <li>
                <Link href="/services/insurance" className="hover:text-accent transition-colors">Insurance</Link>
              </li>
              <li>
                <Link href="/services/custom-orders" className="hover:text-accent transition-colors">Custom Orders</Link>
              </li>
            </ul>
          </FadeIn>

          {/* Newsletter */}
          <FadeIn className="space-y-4" delay={0.4}>
            <h3 className="text-lg font-medium text-text-primary">Newsletter</h3>
            <p>Subscribe to receive updates on new arrivals and special offers.</p>
            <div className="pt-2">
              <div className="flex flex-col sm:flex-row gap-2">
                <input 
                  type="email" 
                  placeholder="Your email" 
                  className="px-4 py-2 bg-primary text-text-primary rounded-full focus:outline-none focus:ring-2 focus:ring-accent/50"
                />
                <Button>Subscribe</Button>
              </div>
            </div>
          </FadeIn>
        </div>

        {/* Bottom */}
        <div className="pt-8 mt-8 border-t border-gray-800 text-sm text-center text-gray-500">
          <p>&copy; {new Date().getFullYear()} Luxury Motors. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
} 