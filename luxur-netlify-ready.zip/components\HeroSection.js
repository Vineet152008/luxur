import Image from 'next/image';
import Link from 'next/link';

export default function HeroSection() {
  return (
    <div className="relative h-screen w-full overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src="https://images.unsplash.com/photo-1618219944342-824e40a13285?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80"
          alt="Luxury Interior Design"
          fill
          priority
          style={{ objectFit: 'cover' }}
          className="brightness-[0.7]"
        />
      </div>
      
      {/* Content Overlay */}
      <div className="relative h-full flex flex-col justify-center items-center text-center text-white px-4">
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-montserrat font-bold mb-6 animate-fade-in">
          Transform Your Space
        </h1>
        <p className="text-lg md:text-xl max-w-2xl mb-10 animate-slide-up">
          Luxurious interior design solutions with a warm minimalist approach that balances aesthetic beauty with practical functionality.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 animate-fade-in" style={{ animationDelay: '0.3s' }}>
          <Link href="/portfolio" className="btn-primary">
            View Our Work
          </Link>
          <Link href="/contact" className="btn-secondary">
            Get in Touch
          </Link>
        </div>
      </div>
      
      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 cursor-pointer animate-bounce">
        <svg 
          xmlns="http://www.w3.org/2000/svg" 
          className="h-10 w-10 text-white" 
          fill="none" 
          viewBox="0 0 24 24" 
          stroke="currentColor"
        >
          <path 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            strokeWidth={2} 
            d="M19 14l-7 7m0 0l-7-7m7 7V3" 
          />
        </svg>
      </div>
    </div>
  );
} 