'use client'

import { useState } from 'react'
import { FadeIn } from '@/components/ui/motion'
import { CarCard } from '@/components/cars/car-card'
import { type Car } from '@/data/cars'

interface CarGridProps {
  cars: Car[]
  title?: string
  subtitle?: string
  limit?: number
}

export function CarGrid({ cars, title, subtitle, limit }: CarGridProps) {
  const [displayCount, setDisplayCount] = useState(limit || cars.length)
  const displayedCars = cars.slice(0, displayCount)
  
  return (
    <section className="py-16">
      {(title || subtitle) && (
        <div className="container mx-auto px-4 md:px-6 mb-12 text-center">
          {title && (
            <FadeIn>
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-text-primary">{title}</h2>
            </FadeIn>
          )}
          {subtitle && (
            <FadeIn delay={0.1}>
              <p className="text-text-secondary max-w-2xl mx-auto">{subtitle}</p>
            </FadeIn>
          )}
        </div>
      )}
      
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8">
          {displayedCars.map((car, index) => (
            <FadeIn key={car.id} delay={index * 0.1} className="h-full">
              <CarCard car={car} />
            </FadeIn>
          ))}
        </div>
        
        {displayCount < cars.length && (
          <div className="mt-12 text-center">
            <button
              onClick={() => setDisplayCount(prev => prev + 6)}
              className="bg-secondary hover:bg-secondary/80 text-text-primary px-8 py-3 rounded-full inline-flex items-center space-x-2 transition-all"
            >
              <span>Load More</span>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M16.707 10.293a1 1 0 010 1.414l-6 6a1 1 0 01-1.414 0l-6-6a1 1 0 111.414-1.414L10 14.586l5.293-5.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
            </button>
          </div>
        )}
      </div>
    </section>
  )
} 