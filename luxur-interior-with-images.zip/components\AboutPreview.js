import Image from 'next/image';
import Link from 'next/link';

export default function AboutPreview() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
      <div className="order-2 lg:order-1">
        <h2 className="section-title mb-6">About Luxur Interior</h2>
        <p className="mb-4">
          Founded with a passion for creating spaces that inspire and comfort, Luxur Interior has established itself as a premier interior design studio specializing in warm minimalism.
        </p>
        <p className="mb-8">
          Our team of passionate designers brings together expertise from various design disciplines to create cohesive, thoughtful interiors that reflect each client's unique personality and lifestyle needs.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
          <div className="flex items-start">
            <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center mr-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-1">Bespoke Design</h3>
              <p className="text-sm">Tailored solutions that perfectly match your style and needs.</p>
            </div>
          </div>
          <div className="flex items-start">
            <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center mr-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-1">Sustainable Choices</h3>
              <p className="text-sm">Eco-friendly materials and ethical practices for responsible design.</p>
            </div>
          </div>
          <div className="flex items-start">
            <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center mr-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z" />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-1">Attention to Detail</h3>
              <p className="text-sm">Meticulous care for every element of your space, from layout to finish.</p>
            </div>
          </div>
          <div className="flex items-start">
            <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center mr-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-1">Timely Delivery</h3>
              <p className="text-sm">Efficient project management to ensure on-time, on-budget completion.</p>
            </div>
          </div>
        </div>
        <Link href="/about" className="btn-secondary">
          Learn More About Us
        </Link>
      </div>
      <div className="order-1 lg:order-2 relative">
        <div className="relative h-[70vh] lg:h-[80vh] overflow-hidden rounded-sm">
          <Image
            src="https://images.unsplash.com/photo-1616486029423-aaa4789e8c9a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80"
            alt="Luxur Interior Design Team"
            fill
            style={{ objectFit: 'cover' }}
            className="transform hover:scale-105 transition-transform duration-700"
          />
        </div>
        <div className="absolute -bottom-8 -left-8 bg-accent text-white p-6 rounded-sm hidden md:block">
          <p className="text-lg font-bold">15+</p>
          <p>Years of Experience</p>
        </div>
        <div className="absolute -top-8 -right-8 bg-accent2 text-white p-6 rounded-sm hidden md:block">
          <p className="text-lg font-bold">200+</p>
          <p>Projects Completed</p>
        </div>
      </div>
    </div>
  );
} 