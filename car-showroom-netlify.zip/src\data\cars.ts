export interface Car {
  id: string;
  brand: string;
  model: string;
  year: number;
  price: number;
  imageUrl: string;
  gallery: string[];
  description: string;
  featured: boolean;
  specifications: {
    engine: string;
    power: string;
    topSpeed: string;
    acceleration: string;
    transmission: string;
    drivetrain: string;
    fuelType: string;
    bodyType: string;
  };
  colors: {
    name: string;
    hex: string;
  }[];
}

export const cars: Car[] = [
  {
    id: 'mercedes-amg-gt-63',
    brand: 'Mercedes-Benz',
    model: 'AMG GT 63 S',
    year: 2023,
    price: 189000,
    imageUrl: 'https://images.unsplash.com/photo-1655617996738-1df1e9931252',
    gallery: [
      'https://images.unsplash.com/photo-1655617996738-1df1e9931252',
      'https://images.unsplash.com/photo-1617814076367-b759c7d7e738',
      'https://images.unsplash.com/photo-1659607735399-db1fc36d8aea',
      'https://images.unsplash.com/photo-1669120778065-08d6f97e0cf4',
    ],
    description: "The Mercedes-AMG GT 63 S is a high-performance four-door coupe that combines exhilarating power with luxury comfort. With its hand-built 4.0-liter V8 biturbo engine, this masterpiece of engineering delivers breathtaking acceleration and responsive handling. The interior is adorned with premium materials and cutting-edge technology, offering both driver and passengers an exceptional experience.",
    featured: true,
    specifications: {
      engine: '4.0L V8 Biturbo',
      power: '630 hp',
      topSpeed: '315 km/h',
      acceleration: '0-100 km/h in 3.2s',
      transmission: '9-speed automatic',
      drivetrain: 'All-wheel drive',
      fuelType: 'Gasoline',
      bodyType: 'Four-door coupe',
    },
    colors: [
      { name: 'Obsidian Black', hex: '#0E0E10' },
      { name: 'Selenite Grey', hex: '#53565A' },
      { name: 'Designo Diamond White', hex: '#F2F3F3' },
      { name: 'Brilliant Blue', hex: '#0B3370' },
    ],
  },
  {
    id: 'lamborghini-huracan-evo',
    brand: 'Lamborghini',
    model: 'Huracán EVO',
    year: 2023,
    price: 330000,
    imageUrl: 'https://images.unsplash.com/photo-1614162692292-7ac56d7f8859',
    gallery: [
      'https://images.unsplash.com/photo-1614162692292-7ac56d7f8859',
      'https://images.unsplash.com/photo-1615537571528-77685149e85c',
      'https://images.unsplash.com/photo-1541899481282-d53bffe3c35d',
      'https://images.unsplash.com/photo-1607854962760-414350031d18',
    ],
    description: "The Lamborghini Huracán EVO represents the evolution of the most successful V10-powered Lamborghini ever. The EVO integrates advanced control systems and innovative aerodynamics into a car designed for maximum driving performance. Its naturally aspirated V10 engine delivers an exhilarating sound and response, while the interior features the finest Italian craftsmanship combined with state-of-the-art technology.",
    featured: true,
    specifications: {
      engine: '5.2L V10',
      power: '640 hp',
      topSpeed: '325 km/h',
      acceleration: '0-100 km/h in 2.9s',
      transmission: '7-speed dual-clutch',
      drivetrain: 'All-wheel drive',
      fuelType: 'Gasoline',
      bodyType: 'Coupe',
    },
    colors: [
      { name: 'Arancio Xanto', hex: '#E97914' },
      { name: 'Verde Mantis', hex: '#78B82A' },
      { name: 'Giallo Spica', hex: '#FFC412' },
      { name: 'Blu Nila', hex: '#2176D8' },
    ],
  },
  {
    id: 'bentley-continental-gt',
    brand: 'Bentley',
    model: 'Continental GT',
    year: 2023,
    price: 280000,
    imageUrl: 'https://images.unsplash.com/photo-1611859266238-4b98091d9d9b',
    gallery: [
      'https://images.unsplash.com/photo-1611859266238-4b98091d9d9b',
      'https://images.unsplash.com/photo-1605470207062-b3081f8df2fd',
      'https://images.unsplash.com/photo-1626142586162-93a1628ab96f',
      'https://images.unsplash.com/photo-1604705492065-4bcfcfdcc11a',
    ],
    description: "The Bentley Continental GT represents the pinnacle of British grand touring. This exquisite automobile combines handcrafted luxury with formidable performance, creating an unparalleled driving experience. The meticulous attention to detail is evident in every stitch of the leather upholstery and each piece of handcrafted wood veneer. The W12 engine provides effortless power, making this the perfect companion for cross-continental journeys.",
    featured: true,
    specifications: {
      engine: '6.0L W12 Twin-turbo',
      power: '650 hp',
      topSpeed: '333 km/h',
      acceleration: '0-100 km/h in 3.7s',
      transmission: '8-speed dual-clutch',
      drivetrain: 'All-wheel drive',
      fuelType: 'Gasoline',
      bodyType: 'Grand Tourer',
    },
    colors: [
      { name: 'Beluga', hex: '#000000' },
      { name: 'St James Red', hex: '#7A121C' },
      { name: 'Glacier White', hex: '#F0F0F0' },
      { name: 'British Racing Green', hex: '#004225' },
    ],
  },
  {
    id: 'aston-martin-db12',
    brand: 'Aston Martin',
    model: 'DB12',
    year: 2023,
    price: 245000,
    imageUrl: 'https://images.unsplash.com/photo-1634403665481-74948d815f03',
    gallery: [
      'https://images.unsplash.com/photo-1634403665481-74948d815f03',
      'https://images.unsplash.com/photo-1561503972-839d2087f974',
      'https://images.unsplash.com/photo-1611859266238-4b98091d9d9b',
      'https://images.unsplash.com/photo-1614162692292-7ac56d7f8859',
    ],
    description: "The Aston Martin DB12 embodies timeless British elegance and cutting-edge performance. As the latest evolution of Aston Martin's grand touring heritage, the DB12 combines breathtaking design with exceptional engineering. The twin-turbocharged V8 engine delivers abundant power, while the bespoke interior offers unrivaled comfort and sophistication. Advanced driver assistance and entertainment systems complement the driving experience without compromising its sporting character.",
    featured: false,
    specifications: {
      engine: '4.0L V8 Twin-turbo',
      power: '671 hp',
      topSpeed: '325 km/h',
      acceleration: '0-100 km/h in 3.5s',
      transmission: '8-speed automatic',
      drivetrain: 'Rear-wheel drive',
      fuelType: 'Gasoline',
      bodyType: 'Grand Tourer',
    },
    colors: [
      { name: 'Magnetic Silver', hex: '#82898F' },
      { name: 'Quantum Silver', hex: '#B9B8B8' },
      { name: 'Onyx Black', hex: '#0A0A0A' },
      { name: 'Ultramarine Black', hex: '#161F2D' },
    ],
  },
  {
    id: 'ferrari-sf90-stradale',
    brand: 'Ferrari',
    model: 'SF90 Stradale',
    year: 2023,
    price: 625000,
    imageUrl: 'https://images.unsplash.com/photo-1677673730072-e4686d5c0144',
    gallery: [
      'https://images.unsplash.com/photo-1677673730072-e4686d5c0144',
      'https://images.unsplash.com/photo-1628773822793-2f0af7beda3f',
      'https://images.unsplash.com/photo-1614882355345-170e47cc8ff5',
      'https://images.unsplash.com/photo-1592853625511-e8c87f8a0560',
    ],
    description: "The Ferrari SF90 Stradale represents the most extreme performance ever achieved by a Ferrari production car. This revolutionary hybrid combines a V8 turbo engine with three electric motors, delivering unparalleled power and acceleration. The state-of-the-art aerodynamics provide maximum downforce, while the driver-centric cockpit integrates digital displays with traditional Ferrari design elements. The SF90 Stradale marks a new chapter in Ferrari's storied history, bridging tradition and future.",
    featured: true,
    specifications: {
      engine: '4.0L V8 Turbo Hybrid',
      power: '986 hp',
      topSpeed: '340 km/h',
      acceleration: '0-100 km/h in 2.5s',
      transmission: '8-speed dual-clutch',
      drivetrain: 'All-wheel drive',
      fuelType: 'Hybrid',
      bodyType: 'Coupe',
    },
    colors: [
      { name: 'Rosso Corsa', hex: '#CC0000' },
      { name: 'Giallo Modena', hex: '#FFF32B' },
      { name: 'Nero Daytona', hex: '#0F0F0F' },
      { name: 'Blu Elettrico', hex: '#0066CC' },
    ],
  },
  {
    id: 'porsche-911-gt3-rs',
    brand: 'Porsche',
    model: '911 GT3 RS',
    year: 2023,
    price: 223000,
    imageUrl: 'https://images.unsplash.com/photo-1611859266238-4b98091d9d9b',
    gallery: [
      'https://images.unsplash.com/photo-1611859266238-4b98091d9d9b',
      'https://images.unsplash.com/photo-1614162692292-7ac56d7f8859',
      'https://images.unsplash.com/photo-1634403665481-74948d815f03',
      'https://images.unsplash.com/photo-1677673730072-e4686d5c0144',
    ],
    description: "The Porsche 911 GT3 RS is the embodiment of Porsche's racing heritage adapted for the road. This track-focused machine features a naturally aspirated flat-six engine that delivers exhilarating performance and an unmistakable sound. Extensive use of lightweight materials and aerodynamic elements, including the distinctive rear wing, maximize downforce and minimize weight. Every aspect of the GT3 RS is designed to provide the most engaging and pure driving experience possible.",
    featured: false,
    specifications: {
      engine: '4.0L Flat-6',
      power: '518 hp',
      topSpeed: '296 km/h',
      acceleration: '0-100 km/h in 3.2s',
      transmission: '7-speed PDK',
      drivetrain: 'Rear-wheel drive',
      fuelType: 'Gasoline',
      bodyType: 'Coupe',
    },
    colors: [
      { name: 'GT Silver Metallic', hex: '#B4B4B4' },
      { name: 'Guards Red', hex: '#FF0600' },
      { name: 'Shark Blue', hex: '#0B506B' },
      { name: 'Python Green', hex: '#9BCF5D' },
    ],
  },
]; 