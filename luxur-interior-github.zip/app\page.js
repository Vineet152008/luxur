import Image from 'next/image';
import Link from 'next/link';
import HeroSection from '../components/HeroSection';
import AboutPreview from '../components/AboutPreview';
import ServicesSection from '../components/ServicesSection';
import PortfolioPreview from '../components/PortfolioPreview';
import TestimonialSlider from '../components/TestimonialSlider';
import ContactCTA from '../components/ContactCTA';
import BlogPreview from '../components/BlogPreview';

export default function Home() {
  return (
    <div className="min-h-screen">
      <HeroSection />
      
      <section id="about-preview" className="py-16">
        <div className="container mx-auto px-4">
          <AboutPreview />
        </div>
      </section>
      
      <section id="services" className="py-16 bg-neutral-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Our Services</h2>
          <ServicesSection />
        </div>
      </section>
      
      <PortfolioPreview />
      
      <TestimonialSlider />
      
      <BlogPreview />
      
      <ContactCTA />
    </div>
  );
} 