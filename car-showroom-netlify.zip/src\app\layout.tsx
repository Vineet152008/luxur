import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Luxury Motors | Exclusive Car Showroom',
  description: 'Experience the extraordinary with our collection of premium luxury vehicles.',
  keywords: 'luxury cars, exotic cars, premium vehicles, car showroom, luxury dealership',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="antialiased">
        {children}
      </body>
    </html>
  )
} 