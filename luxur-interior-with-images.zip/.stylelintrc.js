module.exports = {
  ignoreFiles: ['**/*.js', '**/*.jsx', '**/*.ts', '**/*.tsx'],
  rules: {
    'at-rule-no-unknown': [
      true,
      {
        ignoreAtRules: [
          'tailwind',
          'apply',
          'variants',
          'responsive',
          'screen',
          'layer',
          'extend'
        ],
      },
    ],
    'property-no-unknown': [
      true,
      {
        ignoreProperties: ['line-clamp'],
      },
    ],
    'declaration-block-trailing-semicolon': 'always',
    'no-descending-specificity': null,
    'comment-empty-line-before': null,
    'comment-whitespace-inside': null,
  },
}; 