'use client'

import Link from 'next/link'
import { motion, HTMLMotionProps } from 'framer-motion'
import { cn } from '@/lib/utils'

interface ButtonProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'onDrag'> {
  variant?: 'primary' | 'secondary' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  href?: string;
  className?: string;
}

export function Button({
  children,
  className,
  variant = 'primary',
  size = 'md',
  href,
  ...props
}: ButtonProps) {
  const baseStyles = 'inline-flex items-center justify-center rounded-full font-medium transition-all focus:outline-none focus:ring-2 focus:ring-accent/50';
  
  const variants = {
    primary: 'bg-accent text-black hover:bg-accent/90',
    secondary: 'bg-accent-silver text-black hover:bg-accent-silver/90',
    outline: 'bg-transparent border-2 border-accent text-accent hover:bg-accent/10',
  };
  
  const sizes = {
    sm: 'text-sm px-4 py-1.5',
    md: 'text-base px-6 py-2.5',
    lg: 'text-lg px-8 py-3',
  };
  
  const allStyles = cn(baseStyles, variants[variant], sizes[size], className);
  
  const buttonAnimation = {
    whileHover: { scale: 1.03 },
    whileTap: { scale: 0.97 }
  };
  
  if (href) {
    return (
      <Link href={href} passHref>
        <motion.div 
          className={allStyles}
          {...buttonAnimation}
        >
          {children}
        </motion.div>
      </Link>
    );
  }
  
  // Remove potentially incompatible props from the props object
  const { onDrag, ...safeProps } = props as any;
  
  return (
    <motion.button
      className={allStyles}
      {...buttonAnimation}
      {...safeProps}
    >
      {children}
    </motion.button>
  );
} 