import Image from 'next/image';

export default function Services() {
  const services = [
    {
      id: 1,
      title: 'Residential Design',
      description: 'Transform your home into a warm, minimalist sanctuary that reflects your personality and meets your lifestyle needs. We handle everything from space planning to final styling.',
      image: 'https://images.unsplash.com/photo-1600585152220-90363fe7e115?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      features: [
        'Complete home redesign',
        'Individual room design',
        'Custom furniture selection',
        'Color consultation',
        'Material selection',
        'Lighting design'
      ]
    },
    {
      id: 2,
      title: 'Commercial Spaces',
      description: 'Create impactful commercial environments that enhance your brand identity while ensuring functionality and compliance with commercial regulations.',
      image: 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      features: [
        'Office design',
        'Retail space planning',
        'Hospitality design',
        'Branding integration',
        'Ergonomic workspaces',
        'Commercial lighting'
      ]
    },
    {
      id: 3,
      title: 'Kitchen & Bath Design',
      description: 'Specialized design for the most functional spaces in your home. We blend beauty with practicality to create kitchens and bathrooms that are both stunning and highly functional.',
      image: 'https://images.unsplash.com/photo-1556912167-f556f1f39fdf?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      features: [
        'Layout optimization',
        'Fixture selection',
        'Cabinetry design',
        'Material selection',
        'Lighting design',
        'Storage solutions'
      ]
    },
    {
      id: 4,
      title: 'Staging & Styling',
      description: 'Whether preparing your home for sale or refreshing your space, our staging and styling services will showcase your property\'s best features and create a compelling narrative.',
      image: 'https://images.unsplash.com/photo-1618221118493-9cfa1a1c00da?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      features: [
        'Pre-sale home staging',
        'Seasonal refresh',
        'Accessory selection',
        'Art curation',
        'Furniture arrangement',
        'Color scheme development'
      ]
    }
  ];

  return (
    <div className="min-h-screen py-16">
      <div className="container-custom">
        {/* Hero Section */}
        <div className="relative h-[40vh] mb-16 overflow-hidden rounded-sm">
          <Image
            src="https://images.unsplash.com/photo-1616627975504-facb4bfd41b5?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80"
            alt="Our Design Services"
            fill
            style={{ objectFit: 'cover' }}
            priority
            className="brightness-[0.8]"
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <h1 className="text-4xl md:text-5xl text-white font-bold">Our Services</h1>
          </div>
        </div>

        {/* Introduction */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-2xl font-bold mb-4">Transforming Spaces with Warm Minimalism</h2>
          <p className="text-lg">
            At Luxur Interior, we offer comprehensive design services tailored to your unique needs and preferences. 
            Our approach combines aesthetic excellence with practical functionality, creating spaces that are both 
            beautiful and livable.
          </p>
        </div>

        {/* Services List */}
        <div className="space-y-24 mb-16">
          {services.map((service, index) => (
            <div key={service.id} className={`grid grid-cols-1 lg:grid-cols-2 gap-12 ${index % 2 === 1 ? 'lg:flex-row-reverse' : ''}`}>
              <div className={`relative h-[60vh] overflow-hidden rounded-sm ${index % 2 === 1 ? 'lg:order-2' : ''}`}>
                <Image
                  src={service.image}
                  alt={service.title}
                  fill
                  style={{ objectFit: 'cover' }}
                  className="transition-transform duration-700 hover:scale-105"
                />
              </div>
              <div className={`flex flex-col justify-center ${index % 2 === 1 ? 'lg:order-1' : ''}`}>
                <h2 className="section-title mb-6">{service.title}</h2>
                <p className="text-lg mb-8">{service.description}</p>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-2">
                  {service.features.map((feature, i) => (
                    <li key={i} className="flex items-center">
                      <span className="w-5 h-5 bg-accent rounded-full flex items-center justify-center mr-2">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </span>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        {/* Process Section */}
        <div className="bg-secondary p-12 rounded-sm mb-16">
          <h2 className="section-title text-center mb-12">Our Design Process</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-xl text-white font-bold">1</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Consultation</h3>
              <p>We begin by understanding your vision, needs, and budget to establish a solid foundation for your project.</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-xl text-white font-bold">2</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Concept Development</h3>
              <p>Our designers create conceptual designs that align with your goals and the principles of warm minimalism.</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-xl text-white font-bold">3</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Design Refinement</h3>
              <p>We refine designs based on your feedback, finalizing all elements from materials to furniture.</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-xl text-white font-bold">4</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Implementation</h3>
              <p>Our team oversees the execution of the design, ensuring every detail is perfectly realized.</p>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Ready to Transform Your Space?</h2>
          <p className="text-lg mb-8">Contact us today to schedule a consultation with one of our expert designers.</p>
          <a href="/contact" className="btn-primary inline-block">
            Get in Touch
          </a>
        </div>
      </div>
    </div>
  );
} 