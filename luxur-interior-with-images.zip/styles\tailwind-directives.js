/**
 * This file exists purely to help the Tailwind processor.
 * It is not imported directly into the application.
 */

// @tailwind base;
// @tailwind components;
// @tailwind utilities; 