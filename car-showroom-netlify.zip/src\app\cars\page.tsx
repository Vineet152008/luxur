import { Navbar } from '@/components/layout/navbar'
import { Footer } from '@/components/layout/footer'
import { CarGrid } from '@/components/cars/car-grid'
import { cars } from '@/data/cars'

export const metadata = {
  title: 'Our Collection | Luxury Motors',
  description: 'Browse our exclusive collection of premium luxury vehicles.',
}

export default function CarsPage() {
  return (
    <>
      <Navbar />
      <main className="pt-24">
        <div className="container mx-auto px-4 md:px-6 py-12">
          <h1 className="text-4xl md:text-5xl font-bold text-text-primary mb-4">Our Collection</h1>
          <p className="text-text-secondary text-lg max-w-3xl mb-12">
            Browse through our handpicked selection of the world's most prestigious and sought-after luxury vehicles.
            Each automobile in our collection represents the pinnacle of engineering, design, and luxury.
          </p>
        </div>
        
        <CarGrid 
          cars={cars}
          limit={8}
        />
      </main>
      <Footer />
    </>
  )
} 