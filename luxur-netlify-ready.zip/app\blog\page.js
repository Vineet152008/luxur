import Image from 'next/image';
import Link from 'next/link';

export default function Blog() {
  const blogPosts = [
    {
      id: 1,
      title: 'The Essence of Warm Minimalism in Modern Interiors',
      excerpt: 'Explore how warm minimalism creates spaces that are both aesthetically pleasing and emotionally comforting, striking the perfect balance between sterility and clutter.',
      category: 'Design Trends',
      date: 'October 15, 2023',
      author: 'Jane Doe',
      image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      readTime: '5 min read'
    },
    {
      id: 2,
      title: 'How to Choose the Perfect Color Palette for Your Home',
      excerpt: 'Discover the psychological impact of colors and learn a foolproof method to select a harmonious color scheme that reflects your personality and enhances your space.',
      category: 'Color Theory',
      date: 'September 28, 2023',
      author: 'Emily Chen',
      image: 'https://images.unsplash.com/photo-1586105251261-72a756497a11?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      readTime: '7 min read'
    },
    {
      id: 3,
      title: 'Sustainable Interior Design: Eco-Friendly Choices for Modern Living',
      excerpt: 'Learn how to incorporate sustainable materials and practices into your interior design while maintaining a luxurious aesthetic.',
      category: 'Sustainability',
      date: 'September 10, 2023',
      author: 'John Smith',
      image: 'https://images.unsplash.com/photo-1604014555545-33ab9ce3c0b5?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      readTime: '6 min read'
    },
    {
      id: 4,
      title: 'Small Space Solutions: Maximizing Functionality in Compact Homes',
      excerpt: 'Creative strategies to optimize limited square footage without sacrificing style or comfort. Perfect for urban apartments and tiny homes.',
      category: 'Space Planning',
      date: 'August 22, 2023',
      author: 'Jane Doe',
      image: 'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      readTime: '8 min read'
    },
    {
      id: 5,
      title: 'The Art of Layering Textures in Minimalist Spaces',
      excerpt: 'How to add depth and interest to minimalist interiors through thoughtful texture combinations that enhance the sensory experience of a space.',
      category: 'Textures & Materials',
      date: 'August 5, 2023',
      author: 'Emily Chen',
      image: 'https://images.unsplash.com/photo-1600210492493-0946911123ea?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      readTime: '4 min read'
    },
    {
      id: 6,
      title: 'Lighting Design 101: Creating Ambiance Through Illumination',
      excerpt: 'A comprehensive guide to layered lighting design and how it can transform the mood, functionality, and perceived space of your interiors.',
      category: 'Lighting',
      date: 'July 19, 2023',
      author: 'John Smith',
      image: 'https://images.unsplash.com/photo-1616137422495-1e9e46e2aa77?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      readTime: '9 min read'
    }
  ];

  const categories = [
    'All',
    'Design Trends',
    'Color Theory',
    'Sustainability',
    'Space Planning',
    'Textures & Materials',
    'Lighting'
  ];

  return (
    <div className="min-h-screen py-16">
      <div className="container-custom">
        {/* Hero Section */}
        <div className="relative h-[40vh] mb-16 overflow-hidden rounded-sm">
          <Image
            src="https://images.unsplash.com/photo-1589391886645-d51941baf7fb?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80"
            alt="Our Blog"
            fill
            style={{ objectFit: 'cover' }}
            priority
            className="brightness-[0.8]"
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <h1 className="text-4xl md:text-5xl text-white font-bold">Design Journal</h1>
          </div>
        </div>

        {/* Category Filter */}
        <div className="mb-16 overflow-x-auto">
          <div className="flex space-x-4 pb-4">
            {categories.map((category, index) => (
              <button
                key={index}
                className="px-6 py-2 whitespace-nowrap bg-secondary hover:bg-accent hover:text-white transition-colors duration-300 rounded-sm"
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {/* Featured Post */}
        <div className="bg-secondary rounded-sm overflow-hidden mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="relative h-[60vh] lg:h-auto">
              <Image
                src={blogPosts[0].image}
                alt={blogPosts[0].title}
                fill
                style={{ objectFit: 'cover' }}
                className="transition-transform duration-700 hover:scale-105"
              />
            </div>
            <div className="p-8 md:p-12 flex flex-col justify-center">
              <span className="text-accent text-sm font-medium mb-2">{blogPosts[0].category}</span>
              <h2 className="text-2xl md:text-3xl font-bold mb-4">{blogPosts[0].title}</h2>
              <p className="mb-6">{blogPosts[0].excerpt}</p>
              <div className="flex items-center justify-between mb-6">
                <span className="text-sm">{blogPosts[0].date} • {blogPosts[0].readTime}</span>
                <span className="text-sm font-medium">By {blogPosts[0].author}</span>
              </div>
              <Link href={`/blog/${blogPosts[0].id}`} className="btn-primary self-start">
                Read Article
              </Link>
            </div>
          </div>
        </div>

        {/* Blog Posts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {blogPosts.slice(1).map((post) => (
            <div key={post.id} className="bg-secondary rounded-sm overflow-hidden flex flex-col h-full hover:shadow-md transition-shadow duration-300">
              <div className="relative h-60 overflow-hidden">
                <Image
                  src={post.image}
                  alt={post.title}
                  fill
                  style={{ objectFit: 'cover' }}
                  className="transition-transform duration-700 hover:scale-105"
                />
              </div>
              <div className="p-6 flex flex-col flex-grow">
                <span className="text-accent text-sm font-medium mb-1">{post.category}</span>
                <h3 className="text-xl font-bold mb-3">{post.title}</h3>
                <p className="mb-6 text-sm flex-grow">{post.excerpt}</p>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs">{post.date} • {post.readTime}</span>
                  <span className="text-xs font-medium">By {post.author}</span>
                </div>
                <Link href={`/blog/${post.id}`} className="text-accent hover:underline font-semibold text-sm self-start">
                  Read More →
                </Link>
              </div>
            </div>
          ))}
        </div>

        {/* Subscribe Section */}
        <div className="bg-accent/10 p-12 rounded-sm text-center">
          <h2 className="text-2xl font-bold mb-4">Stay Inspired</h2>
          <p className="max-w-2xl mx-auto mb-8">
            Subscribe to our newsletter for the latest design insights, trends, and exclusive content.
          </p>
          <form className="max-w-md mx-auto flex flex-col sm:flex-row gap-4">
            <input
              type="email"
              placeholder="Your email address"
              className="flex-grow px-4 py-3 border border-gray-200 rounded-sm focus:outline-none focus:border-accent"
            />
            <button type="submit" className="btn-primary whitespace-nowrap">
              Subscribe
            </button>
          </form>
        </div>
      </div>
    </div>
  );
} 