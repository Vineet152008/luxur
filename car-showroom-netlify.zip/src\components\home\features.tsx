'use client'

import { FaTrophy, FaClock, FaShieldAlt, FaHandshake } from 'react-icons/fa'
import { FadeIn, ScaleIn } from '@/components/ui/motion'

const features = [
  {
    icon: FaTrophy,
    title: 'Exclusive Selection',
    description: 'Our collection features the most prestigious and sought-after luxury vehicles from renowned manufacturers worldwide.',
  },
  {
    icon: FaClock,
    title: 'Personalized Experience',
    description: 'From private viewings to bespoke customization, we offer a tailored experience to meet your exact preferences.',
  },
  {
    icon: FaShieldAlt,
    title: 'Quality Assurance',
    description: 'Every vehicle in our collection undergoes a rigorous inspection process to ensure exceptional quality and performance.',
  },
  {
    icon: FaHandshake,
    title: 'Expert Consultation',
    description: 'Our team of automotive specialists provides expert guidance to help you find the perfect vehicle for your needs.',
  },
]

export function Features() {
  return (
    <section className="py-24 bg-gradient-to-b from-primary to-secondary">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <FadeIn>
            <h2 className="text-3xl md:text-4xl font-bold text-text-primary mb-4">
              Why Choose <span className="text-accent">Luxury Motors</span>
            </h2>
          </FadeIn>
          <FadeIn delay={0.1}>
            <p className="text-text-secondary">
              We pride ourselves on delivering an unparalleled luxury experience that goes beyond the extraordinary.
            </p>
          </FadeIn>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <ScaleIn key={feature.title} delay={index * 0.1}>
              <div className="curved-card p-8 h-full flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mb-6">
                  <feature.icon className="text-accent text-2xl" />
                </div>
                <h3 className="text-xl font-semibold text-text-primary mb-3">{feature.title}</h3>
                <p className="text-text-secondary">{feature.description}</p>
              </div>
            </ScaleIn>
          ))}
        </div>
        
        <FadeIn delay={0.5} className="mt-16 text-center">
          <hr className="w-24 border-t-2 border-accent mx-auto mb-8" />
          <p className="text-text-secondary italic max-w-xl mx-auto">
            "Our mission is to provide an extraordinary automotive experience that transcends the ordinary and elevates luxury to new heights."
          </p>
        </FadeIn>
      </div>
    </section>
  )
} 