import Image from 'next/image';

export default function Portfolio() {
  const projects = [
    {
      id: 1,
      title: 'Serene Living Room Redesign',
      description: 'A complete redesign of a living space focusing on warm minimalism with terracotta accents and natural textures.',
      category: 'Residential',
      image: 'https://images.unsplash.com/photo-1616137466211-f939a420be84?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      year: 2023
    },
    {
      id: 2,
      title: 'Modern Office Space',
      description: 'A corporate office transformed with an elegant, productivity-focused design featuring clean lines and functional zones.',
      category: 'Commercial',
      image: 'https://images.unsplash.com/photo-1524758631624-e2822e304c36?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      year: 2023
    },
    {
      id: 3,
      title: 'Luxurious Master Bathroom',
      description: 'A spa-like bathroom renovation with warm tones, custom cabinetry, and premium fixtures for ultimate relaxation.',
      category: 'Bathroom',
      image: 'https://images.unsplash.com/photo-1560185007-cde436f6a4d0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      year: 2022
    },
    {
      id: 4,
      title: 'Minimal Kitchen Design',
      description: 'A clean, functional kitchen featuring custom storage solutions, high-end appliances, and a harmonious color palette.',
      category: 'Kitchen',
      image: 'https://images.unsplash.com/photo-1600489000022-c2086d79f9d4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      year: 2022
    },
    {
      id: 5,
      title: 'Urban Loft Transformation',
      description: 'A complete redesign of a compact urban loft, maximizing space while maintaining an open, airy feel.',
      category: 'Residential',
      image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      year: 2021
    },
    {
      id: 6,
      title: 'Boutique Hotel Lobby',
      description: 'An inviting lobby design that combines luxury with warm minimalism for a memorable first impression.',
      category: 'Commercial',
      image: 'https://images.unsplash.com/photo-1590381105924-c72589b9ef3f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      year: 2021
    },
    {
      id: 7,
      title: 'Tranquil Bedroom Suite',
      description: 'A master bedroom design with a focus on serenity, featuring a carefully curated color palette and natural materials.',
      category: 'Residential',
      image: 'https://images.unsplash.com/photo-1616594039964-ae9021a400a0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      year: 2023
    },
    {
      id: 8,
      title: 'Modern Dining Experience',
      description: 'A dining room that balances elegance with comfort, designed for both intimate family meals and entertaining.',
      category: 'Residential',
      image: 'https://images.unsplash.com/photo-1615968679312-9b7ed9f04e79?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      year: 2022
    },
    {
      id: 9,
      title: 'Executive Office Suite',
      description: 'A sophisticated private office combining functionality with refined aesthetics for a productive workspace.',
      category: 'Commercial',
      image: 'https://images.unsplash.com/photo-1505330622279-bf7d7fc918f4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      year: 2021
    }
  ];

  const categories = ['All', 'Residential', 'Commercial', 'Kitchen', 'Bathroom'];

  return (
    <div className="min-h-screen py-16">
      <div className="container-custom">
        {/* Hero Section */}
        <div className="relative h-[40vh] mb-16 overflow-hidden rounded-sm">
          <Image
            src="https://images.unsplash.com/photo-1618221118493-9cfa1a1c00da?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80"
            alt="Our Portfolio"
            fill
            style={{ objectFit: 'cover' }}
            priority
            className="brightness-[0.8]"
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <h1 className="text-4xl md:text-5xl text-white font-bold">Our Portfolio</h1>
          </div>
        </div>

        {/* Filter Navigation */}
        <div className="flex flex-wrap justify-center mb-16">
          {categories.map((category, index) => (
            <button
              key={index}
              className="px-6 py-2 m-2 bg-secondary hover:bg-accent hover:text-white transition-colors duration-300 rounded-sm"
            >
              {category}
            </button>
          ))}
        </div>

        {/* Portfolio Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {projects.map((project) => (
            <div key={project.id} className="group overflow-hidden rounded-sm bg-secondary shadow-sm hover:shadow-md transition-all duration-300">
              <div className="relative h-72 overflow-hidden">
                <Image
                  src={project.image}
                  alt={project.title}
                  fill
                  style={{ objectFit: 'cover' }}
                  className="transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-accent opacity-0 group-hover:opacity-30 transition-opacity duration-300"></div>
              </div>
              <div className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-xl font-bold">{project.title}</h3>
                  <span className="text-sm bg-accent/10 text-accent px-2 py-1 rounded-sm">{project.category}</span>
                </div>
                <p className="mb-4 text-sm">{project.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-accent">{project.year}</span>
                  <button className="text-sm font-semibold hover:text-accent transition-colors duration-200">
                    View Details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="bg-secondary p-12 rounded-sm text-center">
          <h2 className="text-2xl font-bold mb-4">Have a Project in Mind?</h2>
          <p className="max-w-2xl mx-auto mb-8">
            We'd love to help you transform your space with our warm minimalist approach. 
            Let's discuss how we can bring your vision to life.
          </p>
          <a href="/contact" className="btn-primary inline-block">
            Start a Project
          </a>
        </div>
      </div>
    </div>
  );
} 