import Image from 'next/image';
import Link from 'next/link';

export default function BlogPreview() {
  const recentPosts = [
    {
      id: 1,
      title: 'The Principles of Warm Minimalism in Interior Design',
      excerpt: 'Discover how to create spaces that are clean and minimal yet warm and inviting through thoughtful material selection and design principles.',
      imageUrl: '/images/blog/warm-minimalism.jpg',
      author: 'Emma Davis',
      date: 'May 15, 2023',
      category: 'Design Principles'
    },
    {
      id: 2,
      title: 'Sustainable Materials for Modern Interiors',
      excerpt: 'Explore our curated selection of eco-friendly and sustainable materials that don\'t compromise on style or functionality.',
      imageUrl: '/images/blog/sustainable-materials.jpg',
      author: 'Thomas Chen',
      date: 'April 22, 2023',
      category: 'Sustainability'
    },
    {
      id: 3,
      title: 'Color Psychology in Home Design',
      excerpt: 'Learn how different colors affect mood and atmosphere, and how to use color theory to create the perfect environment for each room.',
      imageUrl: '/images/blog/color-psychology.jpg',
      author: 'Olivia Wilson',
      date: 'March 10, 2023',
      category: 'Color Theory'
    }
  ];

  return (
    <section className="py-20 bg-neutral-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Design Insights</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Explore our latest articles on interior design trends, sustainable living, and creating spaces that enhance wellbeing.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {recentPosts.map((post) => (
            <article key={post.id} className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300">
              <div className="relative h-56 w-full">
                <Image
                  src={post.imageUrl}
                  alt={post.title}
                  fill
                  style={{ objectFit: 'cover' }}
                />
              </div>
              
              <div className="p-6">
                <div className="flex items-center text-sm text-gray-500 mb-3">
                  <span className="bg-accent-light text-accent px-2 py-1 rounded text-xs uppercase">{post.category}</span>
                  <span className="mx-2">•</span>
                  <span>{post.date}</span>
                </div>
                
                <h3 className="text-xl font-bold mb-3">
                  <Link href={`/blog/${post.id}`} className="hover:text-accent transition-colors">
                    {post.title}
                  </Link>
                </h3>
                
                <p className="text-gray-600 mb-4 truncate-3-lines">
                  {post.excerpt}
                </p>
                
                <div className="flex items-center mt-4">
                  <div className="w-8 h-8 bg-gray-300 rounded-full mr-3"></div>
                  <span className="text-sm font-medium">{post.author}</span>
                </div>
              </div>
            </article>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Link 
            href="/blog" 
            className="inline-flex items-center text-accent font-medium hover:underline"
          >
            View All Articles
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
          </Link>
        </div>
      </div>
    </section>
  );
} 