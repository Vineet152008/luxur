import { Navbar } from '@/components/layout/navbar'
import { Footer } from '@/components/layout/footer'
import { FadeIn } from '@/components/ui/motion'
import { Button } from '@/components/ui/button'
import { FaPhone, FaEnvelope, FaMapMarkerAlt, FaClock } from 'react-icons/fa'

export const metadata = {
  title: 'Contact Us | Luxury Motors',
  description: 'Get in touch with our team of luxury automotive experts.',
}

export default function ContactPage() {
  return (
    <>
      <Navbar />
      <main className="pt-24">
        <div className="container mx-auto px-4 md:px-6 py-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            {/* Contact Form */}
            <FadeIn>
              <div className="p-8 rounded-3xl bg-secondary shadow-card">
                <h1 className="text-3xl md:text-4xl font-bold text-text-primary mb-6">Contact Us</h1>
                <p className="text-text-secondary mb-8">
                  Please fill out the form below and one of our luxury automotive specialists will be in touch shortly.
                </p>
                
                <form className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-text-secondary mb-2">
                        Full Name
                      </label>
                      <input 
                        type="text" 
                        id="name"
                        className="w-full px-4 py-3 bg-primary text-text-primary rounded-full focus:outline-none focus:ring-2 focus:ring-accent/50"
                        placeholder="Your name"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-text-secondary mb-2">
                        Email Address
                      </label>
                      <input 
                        type="email" 
                        id="email"
                        className="w-full px-4 py-3 bg-primary text-text-primary rounded-full focus:outline-none focus:ring-2 focus:ring-accent/50"
                        placeholder="Your email"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor="subject" className="block text-sm font-medium text-text-secondary mb-2">
                      Subject
                    </label>
                    <input 
                      type="text" 
                      id="subject"
                      className="w-full px-4 py-3 bg-primary text-text-primary rounded-full focus:outline-none focus:ring-2 focus:ring-accent/50"
                      placeholder="How can we help you?"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-text-secondary mb-2">
                      Message
                    </label>
                    <textarea 
                      id="message"
                      rows={5}
                      className="w-full px-4 py-3 bg-primary text-text-primary rounded-2xl focus:outline-none focus:ring-2 focus:ring-accent/50"
                      placeholder="Your message"
                    ></textarea>
                  </div>
                  
                  <div>
                    <Button type="submit">
                      Send Message
                    </Button>
                  </div>
                </form>
              </div>
            </FadeIn>
            
            {/* Contact Information */}
            <div>
              <FadeIn delay={0.1}>
                <h2 className="text-2xl font-bold text-text-primary mb-6">Visit Our Showroom</h2>
                <p className="text-text-secondary mb-8">
                  Experience our collection in person at our state-of-the-art luxury showroom.
                </p>
                
                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                      <FaMapMarkerAlt className="text-accent" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-text-primary">Address</h3>
                      <p className="text-text-secondary">
                        123 Luxury Lane<br />
                        Manhattan, NY 10001<br />
                        United States
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                      <FaPhone className="text-accent" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-text-primary">Phone</h3>
                      <p className="text-text-secondary">+1 (555) 123-4567</p>
                      <p className="text-text-secondary">+1 (555) 987-6543</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                      <FaEnvelope className="text-accent" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-text-primary">Email</h3>
                      <p className="text-text-secondary">info@luxurymotors.com</p>
                      <p className="text-text-secondary">sales@luxurymotors.com</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                      <FaClock className="text-accent" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-text-primary">Hours</h3>
                      <p className="text-text-secondary">Monday - Friday: 9am - 8pm</p>
                      <p className="text-text-secondary">Saturday: 10am - 6pm</p>
                      <p className="text-text-secondary">Sunday: By appointment only</p>
                    </div>
                  </div>
                </div>
              </FadeIn>
              
              {/* Map Placeholder */}
              <FadeIn delay={0.2} className="mt-10">
                <div className="h-[300px] rounded-3xl bg-primary/50 flex items-center justify-center">
                  <p className="text-text-secondary">Interactive Map Will Be Displayed Here</p>
                </div>
              </FadeIn>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
} 