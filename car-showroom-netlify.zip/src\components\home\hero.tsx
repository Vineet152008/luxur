'use client'

import Image from 'next/image'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { ParallaxImage } from '@/components/ui/motion'

export function Hero() {
  return (
    <section className="relative h-screen min-h-[700px] flex items-center overflow-hidden">
      {/* Background image with parallax effect */}
      <ParallaxImage className="absolute inset-0 z-0">
        <Image
          src="https://images.unsplash.com/photo-1617814076367-b759c7d7e738"
          alt="Luxury car showcase"
          fill
          priority
          className="object-cover brightness-[0.4]"
        />
      </ParallaxImage>
      
      {/* Gradient overlay */}
      <div className="absolute inset-0 z-10 bg-gradient-to-b from-black/60 via-black/30 to-primary" />
      
      {/* Hero content */}
      <div className="container relative z-20 mx-auto px-4 md:px-6 pt-24">
        <div className="max-w-4xl">
          <motion.h1 
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary leading-tight text-shadow"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          >
            Drive the <span className="text-accent">Extraordinary</span>
          </motion.h1>
          
          <motion.p 
            className="mt-6 text-xl text-text-secondary max-w-2xl"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
          >
            Experience the pinnacle of automotive excellence with our curated collection of luxury and performance vehicles.
          </motion.p>
          
          <motion.div 
            className="mt-10 flex flex-wrap gap-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
          >
            <Button href="/cars" size="lg">
              Browse Collection
            </Button>
            <Button href="/contact" variant="outline" size="lg">
              Schedule a Viewing
            </Button>
          </motion.div>
          
          {/* Scroll indicator */}
          <motion.div 
            className="absolute bottom-12 left-1/2 transform -translate-x-1/2 flex flex-col items-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1, duration: 1 }}
          >
            <p className="text-text-secondary text-sm mb-2">Scroll to Explore</p>
            <motion.div 
              className="w-6 h-10 rounded-full border-2 border-text-secondary flex justify-center pt-2"
              animate={{ y: [0, 10, 0] }}
              transition={{ repeat: Infinity, duration: 1.5 }}
            >
              <motion.div className="w-1.5 h-1.5 rounded-full bg-accent" />
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  )
} 