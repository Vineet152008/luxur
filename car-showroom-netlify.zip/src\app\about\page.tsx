import Image from 'next/image'
import { Navbar } from '@/components/layout/navbar'
import { Footer } from '@/components/layout/footer'
import { FadeIn } from '@/components/ui/motion'
import { Button } from '@/components/ui/button'

export const metadata = {
  title: 'About Us | Luxury Motors',
  description: 'Learn about our passion for luxury automobiles and our commitment to excellence.',
}

export default function AboutPage() {
  return (
    <>
      <Navbar />
      <main className="pt-24">
        {/* Hero Section */}
        <section className="relative h-[40vh] lg:h-[50vh] overflow-hidden">
          <Image 
            src="https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7"
            alt="Luxury car showroom"
            fill
            className="object-cover brightness-[0.7]"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/30 to-primary" />
          <div className="container mx-auto px-4 md:px-6 relative z-10 h-full flex items-center">
            <div className="max-w-3xl">
              <h1 className="text-4xl md:text-5xl font-bold text-text-primary mb-4">
                About <span className="text-accent">Luxury Motors</span>
              </h1>
              <p className="text-xl text-text-secondary">
                Our passion for exceptional automobiles drives everything we do
              </p>
            </div>
          </div>
        </section>
        
        {/* Our Story */}
        <section className="py-20">
          <div className="container mx-auto px-4 md:px-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <FadeIn>
                <div className="rounded-3xl overflow-hidden">
                  <Image 
                    src="https://images.unsplash.com/photo-1563720223185-11970d9b15d8"
                    alt="Luxury car showroom interior"
                    width={600}
                    height={400}
                    className="w-full h-auto object-cover"
                  />
                </div>
              </FadeIn>
              
              <FadeIn delay={0.1}>
                <h2 className="text-3xl font-bold text-text-primary mb-6">Our Story</h2>
                <div className="space-y-4 text-text-secondary">
                  <p>
                    Founded in 2005, Luxury Motors began with a simple vision: to create an extraordinary automotive experience that transcends the ordinary dealership model. Our founder, a lifelong car enthusiast, recognized that luxury vehicles deserved a showcase that matched their exceptional nature.
                  </p>
                  <p>
                    What started as a boutique showroom has evolved into the premier destination for discerning automotive collectors and enthusiasts. Over the years, we've built relationships with the world's most prestigious manufacturers, allowing us to offer an unparalleled selection of vehicles.
                  </p>
                  <p>
                    Today, Luxury Motors stands as a testament to automotive excellence, where passion meets precision and every vehicle tells a story of innovation, craftsmanship, and design.
                  </p>
                </div>
              </FadeIn>
            </div>
          </div>
        </section>
        
        {/* Our Values */}
        <section className="py-20 bg-secondary">
          <div className="container mx-auto px-4 md:px-6">
            <FadeIn>
              <div className="text-center max-w-3xl mx-auto mb-16">
                <h2 className="text-3xl font-bold text-text-primary mb-4">Our Values</h2>
                <p className="text-text-secondary">
                  At Luxury Motors, our core values guide everything we do and shape the experience we provide to our clients.
                </p>
              </div>
            </FadeIn>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <FadeIn delay={0.1}>
                <div className="curved-card p-8 h-full">
                  <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mb-6">
                    <span className="text-2xl font-bold text-accent">01</span>
                  </div>
                  <h3 className="text-xl font-semibold text-text-primary mb-3">Excellence</h3>
                  <p className="text-text-secondary">
                    We are committed to excellence in every aspect of our business, from the vehicles we select to the service we provide.
                  </p>
                </div>
              </FadeIn>
              
              <FadeIn delay={0.2}>
                <div className="curved-card p-8 h-full">
                  <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mb-6">
                    <span className="text-2xl font-bold text-accent">02</span>
                  </div>
                  <h3 className="text-xl font-semibold text-text-primary mb-3">Integrity</h3>
                  <p className="text-text-secondary">
                    We operate with unwavering integrity, ensuring transparency and honesty in all our interactions and transactions.
                  </p>
                </div>
              </FadeIn>
              
              <FadeIn delay={0.3}>
                <div className="curved-card p-8 h-full">
                  <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mb-6">
                    <span className="text-2xl font-bold text-accent">03</span>
                  </div>
                  <h3 className="text-xl font-semibold text-text-primary mb-3">Passion</h3>
                  <p className="text-text-secondary">
                    Our passion for extraordinary automobiles drives us to curate a collection that inspires and excites true automotive enthusiasts.
                  </p>
                </div>
              </FadeIn>
            </div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-20">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-4xl mx-auto text-center">
              <FadeIn>
                <h2 className="text-3xl font-bold text-text-primary mb-6">
                  Experience the Luxury Motors Difference
                </h2>
                <p className="text-text-secondary mb-8">
                  We invite you to visit our showroom and experience our collection of exceptional vehicles in person.
                  Our team of automotive experts is ready to provide you with personalized service and guidance.
                </p>
                <div className="flex flex-wrap justify-center gap-4">
                  <Button href="/cars" size="lg">
                    Browse Collection
                  </Button>
                  <Button href="/contact" variant="outline" size="lg">
                    Contact Us
                  </Button>
                </div>
              </FadeIn>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
} 