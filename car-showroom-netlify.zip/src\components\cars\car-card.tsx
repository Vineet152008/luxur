'use client'

import Image from 'next/image'
import Link from 'next/link'
import { FaCar, FaTachometerAlt, FaHorseHead } from 'react-icons/fa'
import { HoverCard } from '@/components/ui/motion'
import { formatCurrency } from '@/lib/utils'
import { type Car } from '@/data/cars'

export function CarCard({ car }: { car: Car }) {
  return (
    <div className="h-full">
      <Link href={`/cars/${car.id}`} legacyBehavior>
        <a className="block h-full">
          <HoverCard className="curved-card h-full overflow-hidden">
            <div className="relative">
              {/* Featured badge */}
              {car.featured && (
                <div className="absolute top-4 left-4 z-10 bg-accent text-black text-xs font-bold px-3 py-1 rounded-full">
                  Featured
                </div>
              )}
              
              {/* Car image */}
              <div className="relative h-60 overflow-hidden">
                <Image 
                  src={car.imageUrl} 
                  alt={`${car.brand} ${car.model}`}
                  fill
                  sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                  className="object-cover transition-all duration-500 hover:scale-110"
                  priority={car.featured}
                />
              </div>
              
              {/* Car details */}
              <div className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-xl font-bold text-text-primary">{car.brand}</h3>
                    <h4 className="text-lg text-accent">{car.model}</h4>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-text-secondary">{car.year}</span>
                    <p className="text-xl font-semibold text-text-primary">
                      {formatCurrency(car.price)}
                    </p>
                  </div>
                </div>
                
                <div className="mt-6 grid grid-cols-3 gap-2 text-center text-text-secondary text-sm">
                  <div className="flex flex-col items-center gap-1">
                    <FaHorseHead className="text-accent" />
                    <span>{car.specifications.power}</span>
                  </div>
                  <div className="flex flex-col items-center gap-1">
                    <FaTachometerAlt className="text-accent" />
                    <span>{car.specifications.topSpeed}</span>
                  </div>
                  <div className="flex flex-col items-center gap-1">
                    <FaCar className="text-accent" />
                    <span>{car.specifications.acceleration}</span>
                  </div>
                </div>
                
                <div className="mt-4 pt-4 border-t border-gray-800 flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-text-secondary">Colors:</span>
                    <div className="flex gap-1">
                      {car.colors.slice(0, 3).map((color) => (
                        <div 
                          key={color.name}
                          className="w-4 h-4 rounded-full border border-gray-700" 
                          style={{ backgroundColor: color.hex }}
                          title={color.name}
                        />
                      ))}
                      {car.colors.length > 3 && (
                        <div className="w-4 h-4 rounded-full bg-secondary border border-gray-700 flex items-center justify-center text-xs">
                          +{car.colors.length - 3}
                        </div>
                      )}
                    </div>
                  </div>
                  <span className="text-xs text-accent underline">View Details</span>
                </div>
              </div>
            </div>
          </HoverCard>
        </a>
      </Link>
    </div>
  )
} 