'use client'

import { Navbar } from '@/components/layout/navbar'
import { Footer } from '@/components/layout/footer'
import { Hero } from '@/components/home/hero'
import { Features } from '@/components/home/features'
import { CarGrid } from '@/components/cars/car-grid'
import { cars } from '@/data/cars'
import { Button } from '@/components/ui/button'
import { FaCar, FaUser, FaPhone, FaEnvelope, FaEdit, FaCheckCircle } from 'react-icons/fa'
import { useState } from 'react'

export default function HomePage() {
  // Get featured cars only
  const featuredCars = cars.filter(car => car.featured)
  const [showSuccessModal, setShowSuccessModal] = useState(false)
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    vehicle: '',
    message: ''
  })
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send the data to your backend
    console.log('Form submitted:', formData)
    // Show success modal
    setShowSuccessModal(true)
    // Reset form
    setFormData({
      fullName: '',
      email: '',
      phone: '',
      vehicle: '',
      message: ''
    })
  }
  
  const closeModal = () => {
    setShowSuccessModal(false)
  }
  
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        
        <Features />
        
        <CarGrid 
          cars={featuredCars} 
          title="Featured Vehicles" 
          subtitle="Discover our handpicked selection of the most exceptional automobiles in our collection."
        />
        
        <section className="py-24 bg-secondary relative overflow-hidden">
          <div className="absolute inset-0 opacity-10 bg-[url('https://images.unsplash.com/photo-1611859266238-4b98091d9d9b')] bg-center bg-no-repeat bg-cover"></div>
          
          <div className="container mx-auto px-4 md:px-6 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <span className="text-accent uppercase tracking-wider text-sm font-medium">
                Experience Luxury
              </span>
              
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mt-3 mb-6 text-text-primary">
                Schedule a Private Viewing
              </h2>
              
              <p className="text-text-secondary mb-8">
                Our showroom offers an exclusive environment where you can explore your dream vehicle at your own pace.
                Our team is ready to provide personalized attention and expert knowledge.
              </p>
              
              <div className="bg-primary/50 backdrop-blur-sm p-8 md:p-10 rounded-3xl shadow-card">
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <FaUser className="text-accent" />
                      </div>
                      <input 
                        type="text" 
                        name="fullName"
                        value={formData.fullName}
                        onChange={handleInputChange}
                        placeholder="Full Name" 
                        required
                        className="w-full pl-12 pr-4 py-3 bg-secondary text-text-primary rounded-full focus:outline-none focus:ring-2 focus:ring-accent/50 transition-all"
                      />
                    </div>
                    
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <FaEnvelope className="text-accent" />
                      </div>
                      <input 
                        type="email" 
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="Email Address" 
                        required
                        className="w-full pl-12 pr-4 py-3 bg-secondary text-text-primary rounded-full focus:outline-none focus:ring-2 focus:ring-accent/50 transition-all"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <FaPhone className="text-accent" />
                      </div>
                      <input 
                        type="tel" 
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        placeholder="Phone Number" 
                        required
                        className="w-full pl-12 pr-4 py-3 bg-secondary text-text-primary rounded-full focus:outline-none focus:ring-2 focus:ring-accent/50 transition-all"
                      />
                    </div>
                    
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <FaCar className="text-accent" />
                      </div>
                      <select 
                        name="vehicle"
                        value={formData.vehicle}
                        onChange={handleInputChange}
                        required
                        className="w-full pl-12 pr-4 py-3 bg-secondary text-text-primary rounded-full focus:outline-none focus:ring-2 focus:ring-accent/50 appearance-none transition-all"
                      >
                        <option value="">Preferred Vehicle</option>
                        {cars.map(car => (
                          <option key={car.id} value={car.id}>
                            {car.brand} {car.model}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                  
                  <div className="relative">
                    <div className="absolute top-3 left-4 pointer-events-none">
                      <FaEdit className="text-accent" />
                    </div>
                    <textarea 
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      placeholder="Additional Information" 
                      rows={4}
                      className="w-full pl-12 pr-4 py-3 bg-secondary text-text-primary rounded-2xl focus:outline-none focus:ring-2 focus:ring-accent/50 transition-all"
                    ></textarea>
                  </div>
                  
                  <div className="flex justify-center pt-2">
                    <button 
                      type="submit" 
                      className="px-8 py-3 bg-accent text-black rounded-full font-medium hover:bg-accent/90 transition-colors focus:outline-none focus:ring-2 focus:ring-accent/50"
                    >
                      Request Appointment
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </section>
        
        {/* Success Modal */}
        {showSuccessModal && (
          <div className="fixed inset-0 flex items-center justify-center z-50 px-4">
            <div className="absolute inset-0 bg-black/60" onClick={closeModal}></div>
            <div className="bg-secondary rounded-3xl p-8 md:p-10 max-w-md w-full relative z-10 transform transition-all">
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-accent/20 flex items-center justify-center mb-6">
                  <FaCheckCircle className="text-accent text-4xl" />
                </div>
                <h3 className="text-2xl font-bold mb-2 text-text-primary">Appointment Requested</h3>
                <p className="text-text-secondary mb-6">
                  Thank you for your interest! Our team will contact you within 24 hours to confirm your private viewing appointment.
                </p>
                <button 
                  onClick={closeModal}
                  className="px-8 py-3 bg-accent text-black rounded-full font-medium hover:bg-accent/90 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
      <Footer />
    </>
  )
} 